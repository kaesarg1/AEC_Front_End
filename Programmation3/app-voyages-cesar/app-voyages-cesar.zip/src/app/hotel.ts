export interface Hotel {

    nom: string;
    adresse: string;
    etoiles: number;
    nmChambres: number;
    photo: string;
    caracteristiques: Array<string>
}
